Contributors
------------

|contributors|

.. |contributors| image:: https://contributors-img.web.app/image?repo=relekang/python-semantic-release
   :target: https://github.com/relekang/python-semantic-release/graphs/contributors
