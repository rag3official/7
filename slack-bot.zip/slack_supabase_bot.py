import os
import json
from datetime import datetime, timedelta
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from supabase import create_client, Client
from dotenv import load_dotenv
import requests
from urllib.parse import urlparse
import mimetypes
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Print environment variables (without sensitive data)
logger.info("Checking environment variables...")
logger.info(f"SUPABASE_URL exists: {bool(os.environ.get('SUPABASE_URL'))}")
logger.info(f"SUPABASE_KEY exists: {bool(os.environ.get('SUPABASE_KEY'))}")
logger.info(f"SLACK_BOT_TOKEN exists: {bool(os.environ.get('SLACK_BOT_TOKEN'))}")
logger.info(f"SLACK_APP_TOKEN exists: {bool(os.environ.get('SLACK_APP_TOKEN'))}")

# Initialize Slack app
app = App(token=os.environ.get("SLACK_BOT_TOKEN"))

# Initialize Supabase client
try:
    supabase: Client = create_client(
        os.environ.get("SUPABASE_URL"),
        os.environ.get("SUPABASE_KEY")
    )
    logger.info("Successfully connected to Supabase")
except Exception as e:
    logger.error(f"Failed to connect to Supabase: {str(e)}")
    raise

def test_supabase_connection():
    """Test the Supabase connection and verify table structure"""
    try:
        # Try to fetch a single row from messages table
        result = supabase.table('messages').select("*").limit(1).execute()
        logger.info("Successfully connected to Supabase messages table")
        
        # Log the table structure
        logger.info("Checking table structure...")
        try:
            # Try to insert a test row
            test_data = {
                'channel_id': 'test_channel',
                'user_id': 'test_user',
                'message_text': 'test message',
                'timestamp': datetime.now().isoformat(),
                'image_urls': [],
                'created_at': datetime.now().isoformat(),
                'message_id': f"test_{datetime.now().timestamp()}",
                'thread_ts': None,
                'parent_message_id': None
            }
            test_result = supabase.table('messages').insert(test_data).execute()
            logger.info(f"Test insert successful: {json.dumps(test_result.data, indent=2)}")
            
            # Clean up test data
            supabase.table('messages').delete().eq('message_id', test_data['message_id']).execute()
            logger.info("Test data cleaned up")
            
        except Exception as e:
            logger.error(f"Error during table structure test: {str(e)}")
            logger.error(f"Error type: {type(e).__name__}")
            return False
            
        return True
    except Exception as e:
        logger.error(f"Failed to connect to Supabase messages table: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        return False

def download_image(url, token):
    """Download image from Slack URL"""
    try:
        logger.info(f"Attempting to download image from URL: {url}")
        response = requests.get(url, headers={'Authorization': f'Bearer {token}'})
        if response.status_code == 200:
            logger.info("Successfully downloaded image")
            return response.content
        logger.error(f"Failed to download image. Status code: {response.status_code}")
        return None
    except Exception as e:
        logger.error(f"Error downloading image: {str(e)}")
        return None

def upload_to_supabase_storage(image_data, filename):
    """Upload image to Supabase Storage"""
    try:
        logger.info(f"Attempting to upload image to Supabase Storage: {filename}")
        # Upload to Supabase Storage
        bucket_name = "van-images"  # Private bucket name
        file_path = f"slack-images/{filename}"
        
        # Upload the file
        result = supabase.storage.from_(bucket_name).upload(
            file_path,
            image_data,
            {"content-type": mimetypes.guess_type(filename)[0] or 'image/jpeg'}
        )
        
        # For private buckets, we need to create a signed URL that expires
        # This URL will be valid for 1 hour (3600 seconds)
        signed_url = supabase.storage.from_(bucket_name).create_signed_url(
            file_path,
            3600  # URL expires in 1 hour
        )
        
        if signed_url and 'signedURL' in signed_url:
            logger.info(f"Successfully uploaded image and generated signed URL")
            return signed_url['signedURL']
        logger.error("Failed to generate signed URL for uploaded image")
        return None
    except Exception as e:
        logger.error(f"Error uploading to Supabase Storage: {str(e)}")
        return None

def save_message_to_supabase(message_data):
    """Save message data to Supabase database"""
    try:
        logger.info("="*50)
        logger.info("ATTEMPTING TO SAVE MESSAGE TO SUPABASE")
        logger.info(f"Message data: {json.dumps(message_data, indent=2)}")
        
        # Ensure image_urls is a list
        image_urls = message_data.get('image_urls', [])
        if not isinstance(image_urls, list):
            image_urls = []
        
        # Prepare the data for insertion
        db_data = {
            'message_id': message_data['message_id'],
            'channel_id': message_data['channel'],
            'user_id': message_data['user'],
            'message_text': message_data['text'],
            'timestamp': message_data['ts'],
            'image_urls': image_urls,  # Store the full image metadata
            'created_at': message_data['created_at'],
            'thread_ts': message_data.get('thread_ts'),
            'parent_message_id': message_data.get('parent_message_id'),
            'image_urls_expiry': (datetime.now() + timedelta(hours=1)).isoformat()
        }
        
        logger.info(f"Prepared database data: {json.dumps(db_data, indent=2)}")
        
        # First, check if message already exists
        existing = supabase.table('messages').select('*').eq('message_id', db_data['message_id']).execute()
        if existing.data:
            logger.info(f"Message already exists, updating: {json.dumps(existing.data, indent=2)}")
            # Update existing message
            result = supabase.table('messages').update(db_data).eq('message_id', db_data['message_id']).execute()
        else:
            # Insert new message
            result = supabase.table('messages').insert(db_data).execute()
        
        logger.info(f"Database operation result: {json.dumps(result.data, indent=2)}")
        logger.info("Successfully saved message to Supabase")
        return result
    except Exception as e:
        logger.error(f"Error saving to Supabase database: {str(e)}")
        logger.error(f"Error details: {type(e).__name__}")
        logger.error(f"Full error: {str(e)}")
        return None

@app.event("file_shared")
def handle_file_shared_events(body, say, client):
    """Handle file shared events"""
    try:
        logger.info("="*50)
        logger.info("FILE SHARED EVENT RECEIVED")
        logger.info("="*50)
        logger.info(f"Event body: {json.dumps(body, indent=2)}")
        
        event = body['event']
        file_id = event['file_id']
        
        # Get file info
        file_info = client.files_info(file=file_id)
        file = file_info['file']
        
        if file.get('mimetype', '').startswith('image/'):
            logger.info(f"Processing shared image file: {file}")
            # Download the image
            image_data = download_image(file['url_private'], os.environ.get("SLACK_BOT_TOKEN"))
            if image_data:
                # Generate filename from URL
                filename = os.path.basename(urlparse(file['url_private']).path)
                if not filename:
                    filename = f"image_{file['id']}.jpg"
                
                # Upload to Supabase Storage
                public_url = upload_to_supabase_storage(image_data, filename)
                if public_url:
                    # Save message data to Supabase
                    message_data = {
                        'channel': event['channel_id'],
                        'user': event['user_id'],
                        'text': f"Shared image: {file['name']}",
                        'ts': event['event_ts'],
                        'image_urls': [public_url]
                    }
                    save_message_to_supabase(message_data)
                    logger.info(f"Successfully processed shared image: {file['name']}")
        
    except Exception as e:
        logger.error(f"Error processing file shared event: {str(e)}")
        raise

@app.event("message")
def handle_message_events(body, say, client):
    """Handle incoming message events"""
    try:
        logger.info("="*50)
        logger.info("NEW MESSAGE RECEIVED")
        logger.info("="*50)
        logger.info(f"Message body: {json.dumps(body, indent=2)}")
        
        event = body['event']
        
        # Skip messages from bots to avoid loops
        if 'bot_id' in event:
            logger.info("Skipping bot message")
            return
        
        # Initialize message data
        message_data = {
            'channel': event['channel'],
            'user': event['user'],
            'text': event.get('text', ''),
            'ts': event['ts'],
            'image_urls': [],
            'message_id': event['ts'],  # Using timestamp as unique message ID
            'thread_ts': event.get('thread_ts'),  # For threaded messages
            'parent_message_id': event.get('thread_ts'),  # For threaded messages
            'created_at': datetime.now().isoformat()
        }
        
        logger.info(f"Processing message: {json.dumps(message_data, indent=2)}")
        
        # Check for files/images in the message
        if 'files' in event:
            logger.info(f"Found files in message: {json.dumps(event['files'], indent=2)}")
            for file in event['files']:
                if file.get('mimetype', '').startswith('image/'):
                    logger.info(f"Processing image file: {json.dumps(file, indent=2)}")
                    # Download the image
                    image_data = download_image(file['url_private'], os.environ.get("SLACK_BOT_TOKEN"))
                    if image_data:
                        # Generate filename from URL
                        filename = os.path.basename(urlparse(file['url_private']).path)
                        if not filename:
                            filename = f"image_{event['ts']}_{len(message_data['image_urls'])}.jpg"
                        
                        # Upload to Supabase Storage
                        public_url = upload_to_supabase_storage(image_data, filename)
                        if public_url:
                            # Store image metadata along with URL
                            image_metadata = {
                                'url': public_url,
                                'filename': filename,
                                'original_name': file.get('name', ''),
                                'mime_type': file.get('mimetype', ''),
                                'size': file.get('size', 0),
                                'created_at': datetime.now().isoformat()
                            }
                            message_data['image_urls'].append(image_metadata)
                            logger.info(f"Added image metadata: {json.dumps(image_metadata, indent=2)}")
        
        # Save message data to Supabase
        try:
            result = save_message_to_supabase(message_data)
            if result:
                logger.info(f"Message saved to Supabase: {json.dumps(result.data, indent=2)}")
            else:
                logger.error("Failed to save message to Supabase - no result returned")
            
            # If this is a threaded message, update the parent message's image_urls
            if message_data.get('thread_ts'):
                try:
                    # Get the parent message
                    parent_result = supabase.table('messages').select('*').eq('message_id', message_data['thread_ts']).execute()
                    if parent_result.data:
                        parent_message = parent_result.data[0]
                        # Update parent message with new image URLs
                        updated_image_urls = parent_message.get('image_urls', []) + message_data['image_urls']
                        update_result = supabase.table('messages').update({
                            'image_urls': updated_image_urls
                        }).eq('message_id', message_data['thread_ts']).execute()
                        logger.info(f"Updated parent message with new image URLs: {json.dumps(update_result.data, indent=2)}")
                except Exception as e:
                    logger.error(f"Error updating parent message: {str(e)}")
            
        except Exception as e:
            logger.error(f"Failed to save message to Supabase: {str(e)}")
            raise
        
    except Exception as e:
        logger.error(f"Error processing message: {str(e)}")
        raise

def main():
    """Main function to start the Slack bot"""
    logger.info("Starting Slack bot...")
    
    # Test Supabase connection before starting
    if not test_supabase_connection():
        logger.error("Failed to connect to Supabase. Exiting...")
        return
    
    # Start the app in Socket Mode
    handler = SocketModeHandler(app, os.environ.get("SLACK_APP_TOKEN"))
    logger.info("Starting Socket Mode handler...")
    handler.start()

if __name__ == "__main__":
    main() 