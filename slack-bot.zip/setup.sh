#!/bin/bash

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Python and pip
sudo apt-get install -y python3 python3-pip python3-venv

# Create directory for the bot
mkdir -p ~/slack-bot
cd ~/slack-bot

# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Copy service file
sudo cp slack-supabase-bot.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable and start the service
sudo systemctl enable slack-supabase-bot
sudo systemctl start slack-supabase-bot

# Check status
sudo systemctl status slack-supabase-bot 